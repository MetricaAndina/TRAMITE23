Namespace tramites

Partial Class tr23cse
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub


    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim WTitulo As String = "Detalle de Cargos realizados a la boleta."

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim i As Integer
        Dim Total As Integer = Convert.ToInt32(Request.Form.Count)
        Dim WPAGINA As String

        For i = 1 To Total - 1
            Session(Request.Form.GetKey(i)) = Request.Form(i).ToString()
        Next

        Try
            Dim col As New ColorConverter
            Session("WCOLOR_LINEA_NEGOCIO") = col.ConvertFromString(Session("WCOLOR_LINEA"))
        Catch ex As Exception
            'Si el color no es v�lido
            Session("WCOLOR_LINEA_NEGOCIO") = Session("WCOLOR_LINEA").Maroon
        End Try
        Session("CUSUARIO") = UCase(Session("CUSUARIO"))
        If Convert.ToString(Session("CUSUARIO")) = "" Then
            EnviarPagina("SesionNet.asp", "tr23resultado.aspx", WTitulo, "010", "", "", "", "", "close")
            Exit Sub
        Else
            WPAGINA = Request.QueryString("WPAG2").Trim
            Response.Redirect(WPAGINA)
        End If
    End Sub

    Public Sub EnviarPagina(ByVal paginaorigen As String, _
                           ByVal paginadestino As String, _
                           ByVal titulo As String, _
                           ByVal imagen As String, _
                           ByVal mensaje1 As String, _
                           ByVal mensaje2 As String, _
                           ByVal mensaje3 As String, _
                           ByVal mensaje4 As String, _
                           ByVal boton As String)

        Response.Redirect(paginadestino & "?paginaorigen=" & paginaorigen & "&mensaje1=" & mensaje1 & "&mensaje2=" & mensaje2 & "&mensaje3=" & mensaje3 & "&mensaje4=" & mensaje4 & "&imagen=" & imagen & "&boton=" & boton)
    End Sub


End Class

End Namespace
